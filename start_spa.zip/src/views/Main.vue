<template>
  <section>
    <h1>The Shop</h1>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Earum ex facilis obcaecati, aperiam perspiciatis dolor? Dolore accusantium doloremque laudantium? Explicabo, vel eligendi exercitationem beatae eum omnis odit. Alias sequi molestiae quo exercitationem ab itaque ex omnis inventore consectetur voluptate explicabo placeat maxime eos, atque quisquam nam ut quos error reiciendis recusandae. Repudiandae sint dolor et, reiciendis, veniam labore animi quam mollitia ullam voluptates vitae ad est quia ratione quis porro libero aspernatur deleniti eaque amet. Reprehenderit doloremque modi laudantium nisi consectetur tempore autem, nostrum dicta nesciunt cumque odit nobis, facere explicabo, rem nemo laboriosam at corrupti recusandae itaque id quos obcaecati eum officiis quod! Ipsum alias repudiandae nemo! Facere culpa vero atque magni reprehenderit, nostrum perferendis in eos distinctio id a vitae sunt ab nisi! Dolorem odio quis similique laudantium praesentium delectus ab animi sit velit? Eveniet exercitationem saepe, temporibus fugit, culpa nam, assumenda sapiente corrupti provident omnis necessitatibus eligendi nisi atque minus aliquid rerum totam sequi possimus. Dignissimos labore atque iusto eum possimus, similique fugit illum, magnam laboriosam, provident harum adipisci neque deleniti. Cumque voluptatum maiores vel sunt eveniet, repellat modi at beatae officiis laudantium ab harum excepturi! Repudiandae delectus esse, laudantium totam maxime commodi provident praesentium reiciendis doloremque facilis reprehenderit ipsa exercitationem, quia laborum. Distinctio tempora mollitia nemo exercitationem, deserunt eum veniam explicabo officiis unde libero. Reprehenderit totam quae animi quod recusandae? Enim autem voluptatum alias maiores ducimus explicabo veritatis, cum ipsam velit doloremque dolorem obcaecati, dolorum distinctio, voluptatibus eligendi deleniti beatae fugit iure cumque eum quae temporibus. Odit neque excepturi commodi. Dolore non deserunt cum. In amet necessitatibus atque, aliquid, dolor tempora numquam id nam veniam qui exercitationem possimus ratione quod modi a, totam officiis natus. Corporis quibusdam fuga numquam vero dolore ad, debitis aliquid maiores dicta omnis consequuntur, sed nemo delectus assumenda aspernatur repellendus tenetur dolor.</p>
  </section>
</template>

<script>
export default {};
</script>

<style leng="scss" scoped>
section {
    padding: 20px;
    display: flex;
    flex-direction: column;
}
h1 {
  text-align: center;
}
p {
  text-align: justify;
}
</style>