<template>
  <section class="mt-1">
    <div class="container bg-secondary rounded p-3">
      <h1>Cotalog</h1>
      <div class="row">
        <div class="col col-sm-3" v-for="good in goods" :key="good.id">
          <b-card
            :title="good.name"
            :img-src="good.img"
            :img-alt="good.name"
            img-top
            tag="article"
            style="max-width: 20rem;"
            class="mb-2"
          >
            <p>${{good.price}}</p>

            <transition enter-active-class="btn-enter" leave-active-class="btn-leave" mode="out-in">
              <button
                v-if="checkInCart(good.id)"
                class="btn btn-danger persp"
                @click="actionsCart({id:good.id,action:'dec'})"
                key="remove"
              >Remove</button>

              <button
                v-else
                class="btn btn-success persp"
                @click="actionsCart({id:good.id})"
                key="add"
              >Add to cart</button>
            </transition>
          </b-card>
        </div>
      </div>
    </div>
  </section>
</template>

<script>
import AppProduct from "../components/good";
import { mapGetters, mapActions } from "vuex";
import { BCard } from "bootstrap-vue";

export default {
  components: {
    AppProduct,
    BCard
  },
  computed: {
    ...mapGetters({ goods: "cotalog/goods", checkInCart: "cart/checkInCart" })
  },
  methods: {
    ...mapActions({ actionsCart: "cart/actionsCart" })
  }
};
</script>
<style lang="scss" scoped>
@keyframes leave {
  from {
    opacity: 1;
  }
  to {
    transform: translateX(30px);
    opacity: 0;
  }
}
@keyframes enter {
  from {
    transform: translateX(-30px);

    opacity: 0;
  }

  to {
    opacity: 1;
    transform: translateX(0);
  }
}

.btn-leave {
  animation: leave 0.3s linear forwards;
}
.btn-enter {
  animation: enter 0.3s linear forwards;
}
</style>